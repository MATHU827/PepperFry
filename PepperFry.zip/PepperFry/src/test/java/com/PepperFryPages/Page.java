package com.PepperFryPages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.PepperFryClass.ExcelUtilities;

public class Page {
	WebDriver driver;
	By find=By.xpath("//*[@id=\"search\"]");
	   By living=By.xpath("//*[@id=\"menu_wrapper\"]/ul/li[2]/a");
	   By BeanBags=By.xpath("//*[@id=\"clp__menu\"]/div[2]/div/ul/li[9]/a");
	   By Clickimg=By.xpath("//*[@id=\"p_5_1_1816165\"]/div/div[1]/a/img");
	   By Rate=By.xpath("//*[@id=\"page\"]/div/div[2]/div/div/div[2]/div[2]/span[2]");
	   
	   public Page(WebDriver driver) {
		   this.driver=driver;
	   }
	   public void navigate()
	   {
		   driver.findElement(living).click();
	   driver.findElement(BeanBags).click();
	   }

	   public void print_rate()
	   {
		  String beanBag_rate= driver.findElement(Rate).getText();
		   System.out.print(beanBag_rate);
	   }
	   public void capture()
	   {
		   driver.findElement(Clickimg).click();
		   
	   }
	   public void search() throws IOException
	   {
		   ExcelUtilities get_data=new ExcelUtilities();
		   driver.findElement(find).sendKeys(get_data.First_item());
		   driver.findElement(find).sendKeys(Keys.ENTER);
		   driver.findElement(find).sendKeys(get_data.excel_Second_item());
		   driver.findElement(find).sendKeys(Keys.ENTER);
		   
	   }
	   
}
