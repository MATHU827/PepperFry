package com.PepperFryClass;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtilities {
	public String First_item() throws IOException 
	{
		FileInputStream fil=new FileInputStream(new File("src/test/resources/TestData/Data.xlsx"));
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("details");
		XSSFRow row=sheet.getRow(1);
    	XSSFCell cell=row.getCell(0);
    	String un=cell.getStringCellValue();
		
		return First_item();
	}
	public String excel_Second_item() throws IOException 
	{
		FileInputStream fil=new FileInputStream(new File("src/test/resources/TestData/Data.xlsx"));
		XSSFWorkbook workbook=new XSSFWorkbook(fil);
		XSSFSheet sheet=workbook.getSheet("details");

		
		XSSFRow row=sheet.getRow(1);
    	XSSFCell cell=row.getCell(2);
    	String un=cell.getStringCellValue();
    	
    	return excel_Second_item();
	}
}
