package comPepperFryTestCase;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.PepperFryClass.WrapperClas;
import com.PepperFryPages.Page;



public class Testcase extends WrapperClas{
	@Before
	public void start()
	{
		launchApplication("firefox","https://www.pepperfry.com/");
	}
	@Test
	public void functions() throws IOException {
		Page details=new Page(driver);
		details.navigate();
		details.print_rate();
		details.capture();
		screenshot("C:\\Users\\hp\\Desktop\\mathu\\PepperFry\\src\\test\\resources\\sceenshot\\bag.png");
		//details.search();
	}
	@After
	public void close()
	{
		quit();	
	}

}
